import SwiftUI

struct ContentView: View {
    var body: some View {
        WebView(url: URL(string: "https://arabic-reading.nafishaider.com/")!)
            .background(Color.white)
    }
}

#Preview {
    ContentView()
}
