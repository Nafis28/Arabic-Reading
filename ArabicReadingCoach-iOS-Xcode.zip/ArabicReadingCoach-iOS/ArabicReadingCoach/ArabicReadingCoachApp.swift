import SwiftUI

@main
struct ArabicReadingCoachApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
