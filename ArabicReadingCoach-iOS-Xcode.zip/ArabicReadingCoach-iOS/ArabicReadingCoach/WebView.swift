import SwiftUI
import WebKit
import UIKit
import AVFoundation

struct WebView: UIViewRepresentable {
    let url: URL

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        configuration.applicationNameForUserAgent = "ArabicReadingCoach/1.0 iOS"

        let preferences = WKWebpagePreferences()
        preferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences = preferences

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.keyboardDismissMode = .interactive
        webView.isOpaque = false
        webView.backgroundColor = .white
        webView.scrollView.backgroundColor = .white

        context.coordinator.webView = webView
        context.coordinator.load(url, in: webView)

        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        // The website is the source of truth. Navigation is handled by WKWebView.
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        webView.stopLoading()
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        private let trustedHost = "arabic-reading.nafishaider.com"
        weak var webView: WKWebView?

        func load(_ url: URL, in webView: WKWebView) {
            var request = URLRequest(url: url)
            request.cachePolicy = .useProtocolCachePolicy
            request.timeoutInterval = 30
            webView.load(request)
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard let targetURL = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }

            let scheme = targetURL.scheme?.lowercased() ?? ""
            let host = targetURL.host?.lowercased() ?? ""

            if scheme == "https" || scheme == "http" {
                if host == trustedHost || host.hasSuffix(".nafishaider.com") {
                    decisionHandler(.allow)
                    return
                }

                decisionHandler(.cancel)
                DispatchQueue.main.async {
                    UIApplication.shared.open(targetURL)
                }
                return
            }

            if ["tel", "mailto", "sms", "facetime"].contains(scheme) {
                decisionHandler(.cancel)
                DispatchQueue.main.async {
                    UIApplication.shared.open(targetURL)
                }
                return
            }

            decisionHandler(.allow)
        }

        @available(iOS 15.0, *)
        func webView(
            _ webView: WKWebView,
            requestMediaCapturePermissionFor origin: WKSecurityOrigin,
            initiatedByFrame frame: WKFrameInfo,
            type: WKMediaCaptureType,
            decisionHandler: @escaping (WKPermissionDecision) -> Void
        ) {
            let isTrusted = origin.protocol.lowercased() == "https" &&
                origin.host.lowercased() == trustedHost

            guard isTrusted else {
                decisionHandler(.deny)
                return
            }

            switch type {
            case .microphone, .camera, .cameraAndMicrophone:
                decisionHandler(.grant)
            @unknown default:
                decisionHandler(.prompt)
            }
        }

        func webView(
            _ webView: WKWebView,
            didFailProvisionalNavigation navigation: WKNavigation!,
            withError error: Error
        ) {
            showOfflinePage(in: webView)
        }

        func webView(
            _ webView: WKWebView,
            didFail navigation: WKNavigation!,
            withError error: Error
        ) {
            let nsError = error as NSError
            if nsError.code == NSURLErrorCancelled { return }
            showOfflinePage(in: webView)
        }

        private func showOfflinePage(in webView: WKWebView) {
            let html = """
            <!doctype html>
            <html lang="en">
            <head>
              <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
              <style>
                :root { color-scheme: light; }
                * { box-sizing: border-box; }
                body {
                  margin: 0;
                  min-height: 100vh;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                  background: #f8fafc;
                  color: #0f172a;
                  text-align: center;
                  padding: 28px;
                }
                .card { max-width: 430px; }
                h2 { margin: 0 0 10px; }
                p { color: #64748b; line-height: 1.5; }
                a {
                  display: inline-block;
                  margin-top: 14px;
                  padding: 13px 22px;
                  border-radius: 12px;
                  background: #0f766e;
                  color: white;
                  text-decoration: none;
                  font-weight: 700;
                }
              </style>
            </head>
            <body>
              <div class="card">
                <h2>You're offline</h2>
                <p>Connect to the internet, then try loading Arabic Reading Coach again.</p>
                <a href="https://arabic-reading.nafishaider.com/">Try again</a>
              </div>
            </body>
            </html>
            """

            webView.loadHTMLString(html, baseURL: URL(string: "https://arabic-reading.nafishaider.com/"))
        }
    }
}
