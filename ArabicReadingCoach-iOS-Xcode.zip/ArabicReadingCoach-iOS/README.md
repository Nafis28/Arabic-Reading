# Arabic Reading Coach - iPhone & iPad

Native SwiftUI/WKWebView wrapper for:

https://arabic-reading.nafishaider.com/

## Included

- iPhone and iPad support
- Native WKWebView
- JavaScript and normal website storage/session support
- Microphone/camera media permission handling limited to the trusted HTTPS host
- Back/forward navigation gestures
- External website links open outside the app
- tel:, sms:, mailto: and FaceTime links open using iOS
- Offline/error screen
- Launch screen
- App icon assets
- Privacy manifest
- iOS 15+ deployment target

## Build on a Mac

1. Install a current supported version of Xcode.
2. Unzip this project.
3. Open `ArabicReadingCoach.xcodeproj`.
4. Select the `ArabicReadingCoach` target.
5. Open **Signing & Capabilities**.
6. Select your Apple Developer Team.
7. Keep or change the bundle identifier:
   `com.nafishaider.ArabicReadingCoach`
8. Connect an iPhone/iPad or choose a simulator.
9. Press **Run**.

For a physical device, test the microphone on a real iPhone/iPad; microphone/web media behaviour should not be judged only from the simulator.

## TestFlight / App Store

1. In Xcode choose **Any iOS Device (arm64)**.
2. Choose **Product > Archive**.
3. In Organizer select the archive.
4. Choose **Distribute App > App Store Connect > Upload**.
5. Finish the listing, privacy answers, screenshots, age rating and review information in App Store Connect.

## Website updates

The native app does not contain a copy of the website. It loads the live URL. Normal website/Cloudflare updates therefore appear in the app without rebuilding the iOS binary.

## Important App Review note

Apple reviews apps for minimum functionality. If the submitted build is considered only a repackaged website, App Review may request additional native/app-specific value. The reading experience, microphone-based interaction, native permissions, error handling and any future native features should be described clearly in the review notes.
